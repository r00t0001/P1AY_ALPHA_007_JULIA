# MARIA 006 · Public V5 · released

Published: 2026-09-19. Public repository and release:
`https://github.com/r00t0001/P1AY_ALPHA_006_MARIA/releases/tag/v5`.
Tag: `v5`. Release commit: `32a2a7a`. This is the first public GitHub release;
`v5` identifies the fifth internal prerelease build, not a fifth public release.

- RU/EN CORE, canonical 77-mechanism map, superseded historical 53-system map, guides, reference, classification, SAVE/migration and acceptance scenarios: included.
- Public/private boundary: only explicit allowlist; real users and personal SAVE excluded.
- Structural verification: run `python3 tools/verify_release.py`; build checks every member, hash, ZIP CRC and extracted contents.
- Local test suite: run `python3 -m unittest discover -s tools -p 'test_*.py'`.
- Behavioral test suite: 45 scenarios per language, NOT_RUN_FOR_V5_HASH. Earlier hashes do not validate V5.
- Independent EN/RU translation and contract-parity review: PASS; see `TRANSLATION_REVIEW.md`.
- Latest participant SAVE files: PARTIAL_RECEIPT. SENYA_0003 full export saved at
  2026-09-19 00:14 +07 and reconciled as an evidence delta; other expected participant
  SAVE files remain pending. Local roster snapshots are not owner-provided updates.
- Press release: OWNER_MANAGED_PENDING, prepared separately.
- V5 package changelog: included in `CHANGELOG.md`; the owner's press release remains separate.
- GitHub repository and v5 release: PUBLISHED / VERIFIED_FROM_PUBLIC_RELEASE_PAGE on
  2026-09-19. Public release commit `32a2a7a` has a GitHub verified signature.

This is a published honest prerelease, not a final-release or independent behavioral
PASS claim. Publication is complete; exact-hash live validation remains a separate
open gate. `RB-001` in `RELEASE_BLOCKS.md` identifies the selective-transfer
privacy/auditability defect; its FIX passed the required second independent technical
review and is CLOSED for this build lineage.

Русский: V5 опубликован на GitHub 2026-09-19. Структурные проверки отделены от
живых модельных тестов. Полный набор новых SAVE, пресс-релиз и live-проверка exact
hash остаются отдельными открытыми условиями; SAVE Сени уже получен и сверен.
Личные профили в GitHub не входят.

## 2026-09-17 acceptance corrections

LEGACY semantics and the complete Russian inline rubric were added after the reviewed V3 archive. V5 preserves the approved 77-mechanism canon, aligns SAVE templates, status vocabulary, safety_state values and REFERENCE.md, and includes the RB-001 selective-transfer fix. Earlier acceptance and live reports do not validate V5 bytes. No historical award audit or participant onboarding is claimed. Live validation remains NOT_RUN_FOR_V5_HASH.

## 2026-09-23 local candidate update (not published)

Conflict rules now precede the CORE closing marker. These changed local bytes are a new candidate, not the original published V5 hash. Local sync runtime, schemas and lossless migration documentation are prepared separately in the workspace sync-runtime package. No real-device round-trip or behavioral PASS is claimed.

## Current integrity status — LOCAL CANDIDATE VERIFIED

The canonical 1–77 registry has been restored from the owner-provided source
text into `CANONICAL_MECHANICS.md` for both languages. `SYSTEMS.md` remains the
historical 1–53 provenance file. The verifier now checks every canonical number
and no longer treats the count marker as proof. Local structural tests: 26/26.
This is a modified local candidate; it is not a new published archive yet.
