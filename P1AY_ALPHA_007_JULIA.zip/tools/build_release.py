"""Build an immutable, deterministic, allowlisted P1AY release repository bundle."""
import argparse
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path
from release_files import FILES,MANIFEST,RELEASE,NAME
from verify_release import verify
ROOT=Path(__file__).resolve().parents[1]

def build(output):
    result=verify(ROOT,require_manifest=False)
    subprocess.run([sys.executable,"-m","unittest","discover","-s",str(ROOT/"tools"),"-p","test_*.py"],check=True)
    assert not output.exists(), 'Choose a new output directory; builds are immutable'
    output.mkdir(parents=True)
    stage=output/'repository';stage.mkdir()
    files=[]
    for name in FILES:
        src=ROOT/name;dest=stage/name;dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(src,dest)
        data=dest.read_bytes()
        files.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'source':name})
    manifest={'release':'ALPHA_007','prerelease':'REVISION_R10','files':files,
        'source_provenance':'Current source files copied byte-for-byte; locale editions derived from approved CORE and canon. Historical originals preserved in the source workspace.',
        'reference_sources':[str(RELEASE/'SOURCE_PROVENANCE.json'),str(RELEASE/'locales/en/CORE.txt'),str(RELEASE/'locales/ru/CORE.txt')],
        'self_reference':{'path':MANIFEST,'hashed_in_files':False},
        'excluded':['real participant SAVE','private profiles','correspondence','secrets','old releases','image experiments','caches','prior ZIPs','.git'],
        'structural_verification':result}
    (stage/MANIFEST).write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    verify(stage,require_manifest=True)
    archive=output/(NAME+'.zip')
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
        for name in sorted(FILES+[MANIFEST]):
            info=zipfile.ZipInfo(name,date_time=(2026,9,18,0,0,0));info.external_attr=0o100644<<16
            z.writestr(info,(stage/name).read_bytes(),compress_type=zipfile.ZIP_DEFLATED)
    with tempfile.TemporaryDirectory() as d,zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert len(z.namelist())==len(set(z.namelist()))
        assert set(z.namelist())==set(FILES)|{MANIFEST}
        z.extractall(d);verify(Path(d),require_manifest=True)
        subprocess.run([sys.executable,"-m","unittest","discover","-s",str(Path(d)/"tools"),"-p","test_*.py"],check=True)
    digest=hashlib.sha256(archive.read_bytes()).hexdigest()
    checksum=output/(archive.name+'.sha256');checksum.write_text(digest+'  '+archive.name+'\n')
    result.update(archive=str(archive.resolve()),sha256=digest,repository=str(stage.resolve()),zip_crc='PASS',extracted_verification='PASS')
    (output/'BUILD_RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',type=Path,default=ROOT/'dist'/NAME)
    build(ap.parse_args().output.resolve())
