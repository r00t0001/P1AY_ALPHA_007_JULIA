"""Explicit public distribution contract for MARIA V5; no recursive inclusion."""
from pathlib import Path
RELEASE = Path('releases/alpha-007')
LANGUAGES = ('en','ru')
LOCALE_FILES = ('CORE.txt','INFO.md','START_CHAT.txt','REFERENCE.md','SYSTEMS.md','SAVE_GUIDE.md','TESTS.txt','SMOKE_TEST.md')
FILES = ['README.md','LICENSE','.gitignore','RELEASE_STATUS.md','RELEASE_BLOCKS.md','TRANSLATION_REVIEW.md','CHANGELOG.md','SECURITY.md','CONTRIBUTING.md']
FILES += ['.github/CODEOWNERS','.github/PULL_REQUEST_TEMPLATE.md','.github/ISSUE_TEMPLATE/bug.yml','.github/ISSUE_TEMPLATE/config.yml']
FILES += [str(RELEASE / name) for name in ('release.json','VALIDATION.json','SOURCE_PROVENANCE.json')]
FILES += [str(RELEASE / 'locales' / lang / name) for lang in LANGUAGES for name in LOCALE_FILES]
FILES += [str(RELEASE / 'templates' / name) for name in ('STATE_SAVE.json','SELECTIVE_SAVE.json','PLAYER.txt','COMMUNICATION.txt')]
FILES += ['tools/'+name for name in ('release_files.py','build_release.py','verify_release.py',
    'validate_way_direction.py','test_validate_way_direction.py','classify_reward.py','test_classify_reward.py','test_release_integrity.py','test_spike_regressions.py')]
MANIFEST = str(RELEASE/'MANIFEST.json')
NAME = 'P1AY_ALPHA_007_JULIA_REVISION_R10'
