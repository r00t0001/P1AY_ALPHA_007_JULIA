"""Verify the exact public allowlist, locale parity, privacy boundary and manifest."""
import hashlib
import json
import re
from pathlib import Path
from release_files import FILES, MANIFEST, RELEASE, LOCALE_FILES, LANGUAGES
from validate_way_direction import validate_way_direction

ROOT = Path(__file__).resolve().parents[1]

CANONICAL_MECHANICS_MARKERS = {
    'en': '# P1▶Y · 77 mechanics',
    'ru': '# P1▶Y · 77 механик',
}

def _numbered_definitions(text):
    """Return numbered definition lines, excluding prose references to counts.

    R10 inlines the description after the bold title on the same line
    ("1. **Title** — description..."); earlier builds put the title alone on
    the numbered line. Accept either.
    """
    return [int(n) for n in re.findall(r'^\s*(\d+)\.\s+\*\*[^*]+\*\*', text, re.M)]

def _assert_canonical_mechanics_are_present(root, lang, core):
    """Never accept a count marker as proof of a canonical mechanics registry.

    R10 folds the canonical 77-mechanism registry into both CORE.txt (appended
    catalog) and SYSTEMS.md (now the same registry, not the old 53-item
    historical file). Both must independently contain definitions 1..77.
    """
    marker = CANONICAL_MECHANICS_MARKERS[lang]
    if marker not in core:
        raise AssertionError((lang, 'missing canonical mechanics marker'))
    definitions = _numbered_definitions(core)
    if len(definitions) == 53:
        raise AssertionError(
            f'{lang}: canonical registry contains only the historical 53 definitions'
        )
    if len(definitions) != 77 or definitions != list(range(1, 78)):
        raise AssertionError((lang, 'canonical mechanics registry must contain definitions 1..77'))

def verify(root=ROOT, require_manifest=None):
    if require_manifest is None:
        require_manifest = (root/MANIFEST).is_file()
    for name in FILES:
        p=root/name
        assert p.is_file() and not p.is_symlink(), f'Missing or symlink: {name}'
        data=p.read_bytes();text=data.decode('utf-8')
        assert len(data)<5_000_000, f'Oversized: {name}'
        forbidden = ('/'+'Users/', '/var/'+'folders/', 'BEGIN '+'PRIVATE KEY', 'BEGIN '+'OPENSSH PRIVATE KEY')
        assert not any(v in text for v in forbidden), f'Private marker: {name}'
        assert not re.search(r'(?:gh[pousr]_|github_pat_)[A-Za-z0-9_]{20,}',text), f'Credential marker: {name}'
        removed_owner = 'player' + 'number0001'
        public_email = 'happy.tv.int' + '@gmail.com'
        assert removed_owner not in text, f'Removed GitHub owner marker: {name}'
        assert public_email not in text, f'Public email marker: {name}'
        if p.suffix=='.json':json.loads(text)
        if p.suffix=='.md':
            for link in re.findall(r'\]\(([^)]+)\)',text):
                target=link.strip('<>').split('#')[0]
                if not target or ':' in target:continue
                q=(p.parent/target).resolve()
                rel=q.relative_to(root.resolve()).as_posix()
                assert rel in FILES or rel==MANIFEST, f'Unpackaged link: {name}: {target}'
    meta=json.loads((root/RELEASE/'release.json').read_text())
    assert meta['release']=='ALPHA_007' and meta['codename_en']=='JULIA'
    assert meta['prerelease']['number']==10 and meta['prerelease']['label']=='REVISION_R10'
    assert meta['repository_name']=='P1AY_ALPHA_007_JULIA' and meta['license']=='MIT'
    assert meta['repository_owner']=='r00t0001'
    assert meta['repository_url']=='https://github.com/r00t0001/P1AY_ALPHA_007_JULIA'
    assert meta['planned_release_date'] is None
    assert meta['github_repository_status']=='NOT_YET_PUBLISHED'
    assert meta['working_copy_status']=='LOCAL_CANDIDATE_NOT_PUBLISHED'
    assert '@r00t0001' in (root/'.github/CODEOWNERS').read_text()
    scenario_sets=[]
    for lang in LANGUAGES:
        folder=root/RELEASE/'locales'/lang
        assert all((folder/f).is_file() for f in LOCALE_FILES)
        core=(folder/'CORE.txt').read_text()
        assert core.rstrip().endswith('END_P1AY_CORE_PORTABLE_ALPHA_007')
        _assert_canonical_mechanics_are_present(root, lang, core)
        for token in ('PROGRESSION_TIER_CLASSIFIER_001','WAY_6BG_3MAIN_001','PRIVATE_PENDING_SELECTION','PAUSED','UNCLASSIFIED_REWARD_CANDIDATE','BUSINESS','ART','ART0','LEGACY','UNKNOWN','0 ▶️ 1 ▶️ 2 ▶️ ∞'):
            assert token in core, (lang,token)
        assert all(axis + ':' in core for axis in ('Scope','Verification','Durability','Impact')), lang
        assert 'GOVERNANCE_MODEL' not in core, 'CORE must reference packaged REFERENCE.md'
        assert all(old not in core for old in ('01▶️2','PRERELEASE V2','PRERELEASE V3','PRERELEASE V4'))
        systems=[int(n) for n in re.findall(r'^\s*(\d+)\.\s+', (folder/'SYSTEMS.md').read_text(), re.M)]
        assert len(systems)==77 and systems==list(range(1,78)),lang
        tests=(folder/'TESTS.txt').read_text()
        assert all(token in tests.splitlines()[0] for token in ('SHA-256','PASS/FAIL/BLOCKED')), lang
        ids=re.findall(r'^(T\d+[ab]?) ',tests,re.M)
        assert len(ids)==len(set(ids))==48,lang
        scenario_sets.append(set(ids))
        scenarios={m.group(1):m.group(2) for m in re.finditer(r'^(T\d+[ab]?) (.+)$',tests,re.M)}
        parity_markers = {
            'en': {'T18':'English launch','T19':'No connected registry','T20':'explicit Yes','T21':'Second explicit Yes','T42':'PAUSED'},
            'ru': {'T18':'Английский старт','T19':'без подключённого реестра','T20':'Первое явное','T21':'Второе явное','T42':'PAUSED'}
        }
        for scenario_id, marker in parity_markers[lang].items():
            assert marker in scenarios[scenario_id], (lang,scenario_id,marker)
        if lang=='en':
            for f in LOCALE_FILES:
                assert not re.search('[А-Яа-яЁё]',(folder/f).read_text()),f'Russian text in EN: {f}'
    assert scenario_sets[0]==scenario_sets[1]
    state=json.loads((root/RELEASE/'templates/STATE_SAVE.json').read_text())
    assert state['schema_version']=='P1AY_SAVE_04'
    assert state['owner']=={'user_id':None,'alias':None,'confirmed':False}
    assert state['safety_state']=='UNKNOWN'
    for key in ('facts','hypotheses','quests','sources','permissions','pending_actions'):assert not state[key]
    assert not validate_way_direction(state)
    save=json.loads((root/RELEASE/'templates/SELECTIVE_SAVE.json').read_text())
    assert save['schema_version']=='P1AY_SELECTIVE_SAVE_02'
    assert save['owner'] is None and save['records']==[] and save['full_player_included'] is False
    assert save['status']=='PREPARED_NOT_SENT'
    assert save['scope']==[] and save['terms'] is None and save['duration'] is None
    assert save['consent']=={'status':'NOT_GRANTED','confirmed_at':None,'evidence':[]}
    assert save['owner_confirmation']=={'status':'NOT_CONFIRMED','confirmed_at':None}
    assert save['provenance']==[] and save['transfer_evidence']==[]
    assert save['revocation']=={'status':'NOT_REQUESTED','requested_at':None,'effective_at':None}
    communication=(root/RELEASE/'templates/COMMUNICATION.txt').read_text()
    assert all(status in communication for status in ('PROPOSED','PREPARED_NOT_SENT'))
    for lang in LANGUAGES:
        core=(root/RELEASE/'locales'/lang/'CORE.txt').read_text()
        assert all(value in core for value in ('UNKNOWN','ANALYZE','PAUSED','PREPARED_NOT_SENT'))
    assert 'REFERENCE_FULL' not in (root/RELEASE/'locales'/'ru'/'CORE.txt').read_text()
    player=(root/RELEASE/'templates'/'PLAYER.txt').read_text()
    assert 'art:' in player and 'level: 0' in player and 'awards: []' in player
    assert '`ЭСТЕТ1КА · AРT_7`' in (root/RELEASE/'locales'/'ru'/'CORE.txt').read_text()
    assert '`ARTISTRY · ART_7`' in (root/RELEASE/'locales'/'en'/'CORE.txt').read_text()
    manifest_path=root/MANIFEST
    if require_manifest:
        manifest=json.loads(manifest_path.read_text())
        assert {r['path'] for r in manifest['files']}==set(FILES)
        for r in manifest['files']:
            data=(root/r['path']).read_bytes()
            assert hashlib.sha256(data).hexdigest()==r['sha256'],r['path']
            assert len(data)==r['bytes']
        actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()
            and not any(x in p.relative_to(root).parts for x in ('.git','dist','__pycache__'))}
        assert actual==set(FILES)|{MANIFEST},f'Unexpected/missing public members: {actual.symmetric_difference(set(FILES)|{MANIFEST})}'
    return {'status':'PASS','public_files':len(FILES),'languages':list(LANGUAGES),'canonical_mechanisms_per_language':77,'manual_scenarios_per_language':48,'live_model_validation':'NOT_RUN_FOR_R10_HASH'}

if __name__=='__main__':
    print(json.dumps(verify(),indent=2))
