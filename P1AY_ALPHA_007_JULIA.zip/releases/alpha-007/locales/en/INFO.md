# P1▶️Y · JULIA 007 · Revision R10

A free, MIT-licensed text protocol for working with context, ideas, tasks and portable personal state in an AI chat. This prerelease candidate has no publication date until exact-hash review is complete.

## Start in English

1. Extract the archive and open a new private AI chat with file support.
2. Attach `CORE.txt` from this English folder.
3. Copy and send `START_CHAT.txt` from the same folder.
4. Choose one task, a new profile, or your own SAVE. For continuation, attach only your own selected SAVE and verify ownership. No registration is required for a trial task.

If attachments are unavailable, paste the complete CORE followed by START_CHAT. The AI must say if it cannot read the file. Do not upload the entire repository or anyone else's profile.

## Files

- `CORE.txt`: complete current operating protocol in English.
- `REFERENCE.md`: architecture, permissions, governance and classification.
- `SYSTEMS.md`: the superseded historical 53-system map and its implementation boundary; the current CORE carries the canonical 77-mechanism map.
- `SAVE_GUIDE.md`: separate owners, selective transfer and version migration.
- `TESTS.txt`: behavioral acceptance scenarios; reading them is not a test run.
- `SMOKE_TEST.md`: exact-hash live test procedure.
- `../../templates/STATE_SAVE.json`: empty current P1AY_SAVE_04 state template.
- `../../templates/SELECTIVE_SAVE.json`: empty selective-transfer template.
- `../../templates/PLAYER.txt`, `../../templates/COMMUNICATION.txt`: empty working forms.
- `../../release.json`, `../../VALIDATION.json`, `../../MANIFEST.json`: release identity, honest verification status and file provenance.

Personal/world progression and BUSINESS progression stay separate. No real participant SAVE, correspondence, secret or private ledger is included. Each person keeps their own private files; new owner-provided SAVE files remain pending until received and checked.

This package supplies rules and local validators, not a hosted application, authentication service, registry, cloud sync, payments or universal model compatibility. Provider accounts/fees and data-storage terms are external. Text privacy labels do not encrypt data. Live model results must name the exact build hash; old results do not validate R10.

The press release and changelog are being prepared separately by the owner and are not authored or substituted here.
