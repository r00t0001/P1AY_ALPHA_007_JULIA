# Release blocks

## RB-001 — selective-transfer privacy and auditability

- Severity: CRITICAL
- Affected component: `releases/alpha-007/templates/SELECTIVE_SAVE.json` and selective SAVE transfer
- Status: CLOSED / FIX_ACCEPTED
- Symptom: the earlier `P1AY_SELECTIVE_SAVE_01` template required a recipient and purpose but had no structured consent, owner confirmation, scope, terms, duration, provenance, transfer evidence or revocation record. The verifier checked none of those fields.
- Affected contract: CORE requires exact-data preview, scoped permission and confirmation before transfer; REFERENCE requires owner, recipient, scope, purpose, terms, duration, revocation, evidence and status for every exchange.
- Risk: a transfer could be represented without enough evidence to audit authorization, origin or later revocation. This is a privacy/identity auditability defect and can cause provenance loss.
- Evidence: independent read-only review of the 77-mechanism prerelease candidate identified the schema/contract mismatch. The finding is reproducible by comparing the earlier template with CORE visibility/transfer rules and REFERENCE exchange requirements.
- FIX: `P1AY_SELECTIVE_SAVE_02` adds fail-closed consent and owner-confirmation states plus explicit scope, terms, duration, provenance, transfer evidence and revocation. The verifier and regression suite assert the empty safe defaults. RU/EN SAVE guides describe the new contract.
- Minimum clearance condition: generated manifest and extracted archive verification PASS; regression suite PASS; a second independent technical reviewer confirms that the schema, verifier and RU/EN guidance close the mismatch without weakening empty-selection or PREPARED_NOT_SENT behavior.
- Review disposition: a second independent technical review accepted the schema, verifier, regression coverage, bilingual guidance and gate wording. Revalidate this decision whenever those files change; later archives require their own exact-hash receipt.

Final-release gates outside RB-001 remain listed in `RELEASE_STATUS.md` and `releases/alpha-007/VALIDATION.json`.
