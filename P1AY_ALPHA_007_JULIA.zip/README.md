# P1▶️Y · ALPHA 007 · JULIA · Revision R10

**English:** a free, open-source text protocol for working with context, ideas, tasks and portable personal state in an AI chat. **Русский:** бесплатный открытый текстовый протокол для работы с контекстом, идеями, задачами и личным состоянием.

## Choose your language / Выберите язык

- [English: start here](releases/alpha-007/locales/en/INFO.md)
- [Русский: начать здесь](releases/alpha-007/locales/ru/INFO.md)

[What changed in R10 / Что изменилось в R10](CHANGELOG.md)

Use the CORE and START_CHAT from one language folder. Attach your own SAVE only when continuing an existing profile. Public templates contain no real participant data. Personal/world and BUSINESS progression are separate.

Используйте CORE и START_CHAT одного языка. Для продолжения приложите только собственный SAVE. Публичные шаблоны пустые; личный/world и BUSINESS учитываются отдельно.

Release date / Дата публикации: **TBD / будет назначена после проверки**. This is the JULIA 007 R10 prerelease candidate prepared for `r00t0001/P1AY_ALPHA_007_JULIA`, superseding MARIA 006 V5. Nothing in this source tree is a published GitHub Release yet. [Metadata](releases/alpha-007/release.json) · [Verification status](releases/alpha-007/VALIDATION.json) · [Release blocks](RELEASE_BLOCKS.md) · [Translation review](TRANSLATION_REVIEW.md).

## Package and verification / Комплект и проверки

The clean distribution contains both complete CORE editions, the canonical 77-mechanism product map (now shared by CORE and SYSTEMS.md), reference guides, the evidence-gated Tier classifier, SAVE/migration instructions, empty working templates, behavioral scenarios and local validators. Historical releases, image experiments, caches, correspondence, real profiles and backups are excluded from distribution and preserved in the private source workspace.

Чистый комплект содержит обе языковые редакции CORE, каноническую карту 77 механик (теперь общую для CORE и SYSTEMS.md), справочники, классификацию Tier, инструкции SAVE/миграции, пустые шаблоны, сценарии и валидаторы. История, графические эксперименты, личные профили и backup не публикуются.

Requires Python 3.9+ for local checks; no external packages required. From the repository root:

```sh
python3 tools/verify_release.py
python3 -m unittest discover -s tools -p 'test_*.py'
python3 tools/build_release.py
```

The build uses an explicit file allowlist, verifies the extracted ZIP and produces SHA-256 checksums. Structural tests do not prove live AI behavior. [Live smoke: EN](releases/alpha-007/locales/en/SMOKE_TEST.md) · [RU](releases/alpha-007/locales/ru/SMOKE_TEST.md). No live PASS is claimed for R10 until exact-hash receipts exist.

Latest participant SAVE files are still awaited. The R10 package changelog is included; the owner prepares the separate press release. The final launch remains pending those inputs and review.

Последние SAVE участников ещё ожидаются. Changelog R10 включён в комплект; отдельный пресс-релиз готовит владелец. Окончательный выпуск ждёт этих материалов и проверки.

[MIT license](LICENSE) · [Security policy](SECURITY.md) · [Contributing](CONTRIBUTING.md). AI-provider accounts, pricing and storage rules are external. No built-in hosting, global registry, cloud synchronization or payment service is supplied.

## Historical levels / Исторические уровни

Pre-PROGRESSION_TIER_CLASSIFIER_001 levels are preserved as LEGACY: not comparable with the current scale and not verified by the current classifier. Display LEGACY beside each such level in profiles, statistics and SAVE exports. Preserve original numbers, events, scale and provenance separately from current verified points; never add the scales together. Do not erase history or automatically convert it into current awards. Reclassification requires a separate explicit procedure with the full gate and duplicate checks; event_id and dedup_group identify events but do not replace evidence or an independent verifier. An event failing the gate remains UNCLASSIFIED_REWARD_CANDIDATE without current points. Awards already claimed under the new scale without the full gate are verification conflicts, not automatically LEGACY or VERIFIED.

Исторические уровни до PROGRESSION_TIER_CLASSIFIER_001 сохраняются как LEGACY: не сопоставимы с текущей шкалой и не подтверждены текущим классификатором. Показывай LEGACY рядом с каждым таким уровнем в профиле, статистике и SAVE. Сохраняй исходные числа, события, шкалу и provenance отдельно от текущих подтверждённых points; не складывай шкалы. Не обнуляй историю и не превращай её в текущие награды автоматически. Переоценка проводится отдельной явной процедурой с полным gate и проверкой дублей; event_id и dedup_group обеспечивают идентификацию, но не заменяют evidence и независимого verifier. Не прошедшее gate событие остаётся UNCLASSIFIED_REWARD_CANDIDATE без текущих points. Начисления, уже заявленные по новой шкале без полного gate, являются конфликтом проверки, а не автоматически LEGACY или VERIFIED.
