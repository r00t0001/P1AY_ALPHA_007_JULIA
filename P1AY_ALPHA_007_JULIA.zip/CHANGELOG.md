# MARIA 006 · V4 → V5

V5 — новая prerelease-сборка, а не переупаковка V4. Живые результаты и receipts V4 не переносятся на V5.

## Product canon

- Зафиксирован утверждённый канон **77 механик**.
- Карта 53 систем больше не текущий канон и сохранена только как superseded provenance.
- CORE, INFO, REFERENCE и release metadata выровнены по V5, 77 mechanisms и историческому статусу 53-system map.

## Privacy and selective SAVE

- `P1AY_SELECTIVE_SAVE_01` заменён на `P1AY_SELECTIVE_SAVE_02`.
- Добавлены `scope`, `terms`, `duration`, `consent`, `owner_confirmation`, `provenance`, `transfer_evidence` и `revocation`.
- Передача fail-closed: `NOT_GRANTED` или `NOT_CONFIRMED` не разрешает sharing.
- Verifier и regression suite проверяют безопасные пустые значения.
- Critical finding оформлен как `RB-001`; FIX принят вторым независимым technical review, статус `CLOSED / FIX_ACCEPTED`.

## Release integrity

- ZIP, `repository`, `MANIFEST.json` и SHA-256 генерируются из одного allowlisted source tree.
- CLI-verifier больше не игнорирует существующий stale manifest.
- Добавлены `SECURITY.md`, `CONTRIBUTING.md`, `RELEASE_BLOCKS.md` и `TRANSLATION_REVIEW.md`.
- Critical release gate: `FIX` или `SCOPE_OUT` **и** второй независимый technical review.

## EN/RU behavioral parity

- Исправлена семантика scenario IDs `T18–T22` в EN/RU suites.
- `T42` в обоих языках сохраняет PAUSED и не запускает onboarding до явного resume.
- Оба TESTS-набора требуют platform/model, date/time, exact build SHA-256, exact input/full response и PASS/FAIL/BLOCKED.
- Verifier проверяет critical per-ID parity markers, а не только множество ID.
- Независимый EN/RU contract-parity review: PASS.

## Verification delta

- Automated suite: **25 → 26 tests**.
- Public allowlist: **37 → 41 files**; `MANIFEST.json` считается отдельно.
- Behavioral scenarios: 45 на язык, с исправленным EN/RU mapping.

## Unchanged external gates

- ChatGPT live: `NOT_RUN_FOR_V5_HASH`.
- Claude live: `NOT_RUN_FOR_V5_HASH`.
- Full behavioral suite: `NOT_RUN_FOR_V5_HASH`.
- Latest participant SAVE intake: `AWAITING_LATEST_OWNER_PROVIDED_SAVES`.
- Owner-managed press release: `PENDING`.

V5 можно публиковать как честный GitHub prerelease candidate. До exact-hash live receipts нельзя заявлять behavioral PASS или final release.
