# Independent EN/RU translation and contract-parity review

Status: PASS

Scope: all eight English/Russian locale pairs in JULIA 007 Revision R10, including CORE, INFO, START_CHAT, REFERENCE, SYSTEMS, SAVE_GUIDE, TESTS and SMOKE_TEST.

The review confirmed aligned R10 identity, canonical 77-mechanism status, shared 77-mechanism registry across CORE and SYSTEMS.md, `P1AY_SELECTIVE_SAVE_02` fail-closed privacy contract, reward/status vocabulary and live-test receipt requirements.

The initial review found and rejected mismatched behavioral mappings: T18/T19 were swapped, T20/T21 had different semantics, RU T42 omitted the PAUSED gate, and the RU receipt preamble omitted exact SHA-256 plus PASS/FAIL/BLOCKED. Those discrepancies were corrected. The follow-up review confirmed:

- T18 is English launch in both suites.
- T19 is no-connected-registry behavior in both suites.
- T20 tests the first expansion YES; T21 tests the second same-subject significance commit.
- T22 covers broken/ambiguous/random-YES chains without losing ordinary source preservation.
- T42 preserves PAUSED and delays onboarding until an explicit resume.
- Both suite preambles require platform/model, time, exact build SHA-256, exact input/full response and PASS/FAIL/BLOCKED.
- Both START_CHAT files explicitly declare their default response language.

The verifier now asserts the critical per-ID parity markers so equal ID sets cannot conceal these contract swaps again.

This is a textual and contractual parity review, not a live-model behavioral PASS. Live ChatGPT and Claude results remain separate exact-hash gates.
